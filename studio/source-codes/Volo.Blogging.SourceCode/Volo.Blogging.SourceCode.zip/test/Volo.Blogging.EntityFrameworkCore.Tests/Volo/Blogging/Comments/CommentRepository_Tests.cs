﻿using Volo.Blogging.Comments;
using Volo.Blogging.EntityFrameworkCore;

namespace Volo.Blogging
{
    public class CommentRepository_Tests : CommentRepository_Tests<BloggingEntityFrameworkCoreTestModule>
    {
    }
}