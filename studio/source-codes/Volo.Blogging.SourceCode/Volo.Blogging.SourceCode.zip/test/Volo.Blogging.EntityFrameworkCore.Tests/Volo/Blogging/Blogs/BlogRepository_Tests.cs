﻿using Volo.Blogging.Blogs;
using Volo.Blogging.EntityFrameworkCore;

namespace Volo.Blogging
{
    public class BlogRepository_Tests : BlogRepository_Tests<BloggingEntityFrameworkCoreTestModule>
    {
    }
}