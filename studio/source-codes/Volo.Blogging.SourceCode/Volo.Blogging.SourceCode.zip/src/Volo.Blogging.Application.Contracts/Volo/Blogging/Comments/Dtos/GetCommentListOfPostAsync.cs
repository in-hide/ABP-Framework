﻿using System;

namespace Volo.Blogging.Comments.Dtos
{
    public class GetCommentListOfPostAsync
    {
        public Guid PostId { get; set; }
    }
}