﻿namespace Volo.Blogging.Tagging.Dtos
{
    public class PopularTagDto
    {
        public TagDto Tag { get; set; }

        public int Count { get; set; }
    }
}