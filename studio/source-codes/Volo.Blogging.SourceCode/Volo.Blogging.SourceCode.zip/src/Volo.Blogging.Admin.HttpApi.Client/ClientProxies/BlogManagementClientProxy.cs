// This file is part of BlogManagementClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Blogging.Admin.ClientProxies;

public partial class BlogManagementClientProxy
{
}
